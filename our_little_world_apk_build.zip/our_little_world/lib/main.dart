import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:home_widget/home_widget.dart';
import 'package:shared_preferences/shared_preferences.dart';

const pink = Color(0xFFF4AFC6);
const ink = Color(0xFF342A35);
const cream = Color(0xFFFFF8F5);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await HomeWidget.setAppGroupId('group.com.example.ourlittleworld');
  runApp(const OurLittleWorldApp());
}

class OurLittleWorldApp extends StatelessWidget {
  const OurLittleWorldApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Our Little World',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: cream,
      colorScheme: ColorScheme.fromSeed(seedColor: pink, brightness: Brightness.light),
      appBarTheme: const AppBarTheme(backgroundColor: cream, foregroundColor: ink),
      cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22))),
    ),
    home: const MainShell(),
  );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int tab = 0;
  final pages = const [HomePage(), DrawPage(), PetPage(), LovePage(), SettingsPage()];
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: IndexedStack(index: tab, children: pages)),
    bottomNavigationBar: NavigationBar(
      selectedIndex: tab,
      onDestinationSelected: (v) => setState(() => tab = v),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.brush_rounded), label: 'Draw'),
        NavigationDestination(icon: Icon(Icons.pets_rounded), label: 'Pets'),
        NavigationDestination(icon: Icon(Icons.favorite_rounded), label: 'Love'),
        NavigationDestination(icon: Icon(Icons.settings_rounded), label: 'Settings'),
      ],
    ),
  );
}

Widget heading(String title, String subtitle) => Padding(
  padding: const EdgeInsets.fromLTRB(20, 22, 20, 12),
  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: ink)),
    const SizedBox(height: 5),
    Text(subtitle, style: TextStyle(color: ink.withOpacity(.65))),
  ]),
);

Widget softCard({required Widget child}) => Card(
  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
  child: Padding(padding: const EdgeInsets.all(16), child: child),
);

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(children: [
    heading('Our Little World ♡', 'A tiny world made for two.'),
    softCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Today in your little world', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: const [
        CharacterBadge(emoji: '🔥', name: 'Ember'),
        Text('♡', style: TextStyle(fontSize: 30, color: pink)),
        CharacterBadge(emoji: '💧', name: 'Wade'),
      ]),
      const SizedBox(height: 10),
      const Text('Your fire-and-water duo is waiting for you.', textAlign: TextAlign.center),
    ])),
    softCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
      Text('Your shared space', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      SizedBox(height: 8),
      Text('Draw together, care for your characters, and save your special dates.'),
      SizedBox(height: 8),
      Chip(avatar: Icon(Icons.cloud_off, size: 17), label: Text('Prototype mode · local on this phone')),
    ])),
    softCard(child: const Row(children: [
      Icon(Icons.widgets_outlined, color: pink, size: 30),
      SizedBox(width: 12),
      Expanded(child: Text('Home-screen widgets are prepared as a next integration step. This starter does not sync between phones yet.')),
    ])),
  ]);
}

class CharacterBadge extends StatelessWidget {
  final String emoji, name;
  const CharacterBadge({super.key, required this.emoji, required this.name});
  @override
  Widget build(BuildContext context) => Column(children: [
    CircleAvatar(radius: 34, backgroundColor: const Color(0xFFFFEEF3), child: Text(emoji, style: const TextStyle(fontSize: 34))),
    const SizedBox(height: 5), Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
  ]);
}

class Stroke {
  final List<Offset> points;
  final Color color;
  final double width;
  Stroke(this.points, this.color, this.width);
}

class DrawPage extends StatefulWidget {
  const DrawPage({super.key});
  @override
  State<DrawPage> createState() => _DrawPageState();
}

class _DrawPageState extends State<DrawPage> {
  final List<Stroke> strokes = [];
  Stroke? active;
  Color selected = const Color(0xFFEA729C);
  final colors = [const Color(0xFFEA729C), const Color(0xFF5A9BD5), const Color(0xFF6BBF91), const Color(0xFF342A35), Colors.orange, Colors.purple];
  @override
  Widget build(BuildContext context) => Column(children: [
    heading('Draw together 🎨', 'Leave a little doodle for each other.'),
    Expanded(child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ClipRRect(borderRadius: BorderRadius.circular(22), child: Container(
        color: Colors.white,
        child: GestureDetector(
          onPanStart: (d) => setState(() { active = Stroke([d.localPosition], selected, 5); strokes.add(active!); }),
          onPanUpdate: (d) => setState(() => active?.points.add(d.localPosition)),
          onPanEnd: (_) => setState(() => active = null),
          child: CustomPaint(painter: DrawingPainter(strokes), child: const SizedBox.expand()),
        ),
      )),
    )),
    Padding(padding: const EdgeInsets.all(14), child: Wrap(alignment: WrapAlignment.center, spacing: 12, runSpacing: 8, children: [
      for (final c in colors) InkWell(onTap: () => setState(() => selected = c), child: CircleAvatar(radius: 15, backgroundColor: c, child: selected == c ? const Icon(Icons.check, color: Colors.white, size: 16) : null)),
      OutlinedButton.icon(onPressed: () => setState(() { if (strokes.isNotEmpty) strokes.removeLast(); }), icon: const Icon(Icons.undo), label: const Text('Undo')),
      OutlinedButton.icon(onPressed: () => setState(strokes.clear), icon: const Icon(Icons.delete_outline), label: const Text('Clear')),
    ])),
    const Padding(padding: EdgeInsets.only(bottom: 10), child: Text('Prototype: drawings stay on this device for now.', style: TextStyle(fontSize: 12, color: Colors.black54))),
  ]);
}

class DrawingPainter extends CustomPainter {
  final List<Stroke> strokes;
  DrawingPainter(this.strokes);
  @override
  void paint(Canvas canvas, Size size) {
    for (final s in strokes) {
      final p = Paint()..color = s.color..strokeWidth = s.width..strokeCap = StrokeCap.round..style = PaintingStyle.stroke;
      if (s.points.length == 1) canvas.drawCircle(s.points.first, s.width / 2, Paint()..color = s.color);
      for (int i = 1; i < s.points.length; i++) canvas.drawLine(s.points[i - 1], s.points[i], p);
    }
  }
  @override
  bool shouldRepaint(covariant DrawingPainter oldDelegate) => true;
}

class PetPage extends StatefulWidget {
  const PetPage({super.key});
  @override
  State<PetPage> createState() => _PetPageState();
}

class _PetPageState extends State<PetPage> {
  int hunger = 65, clean = 70, happy = 80, energy = 75, outfit = 0;
  final outfits = ['Everyday', 'Cozy hoodie', 'Party look', 'Matching set'];
  void change(String action) {
    setState(() {
      if (action == 'Feed') hunger = (hunger + 15).clamp(0, 100).toInt();
      if (action == 'Groom') clean = (clean + 15).clamp(0, 100).toInt();
      if (action == 'Play') { happy = (happy + 15).clamp(0, 100).toInt(); energy = (energy - 10).clamp(0, 100).toInt(); }
      if (action == 'Nap') energy = (energy + 20).clamp(0, 100).toInt();
    });
  }
  Widget meter(String label, int value, IconData icon) => Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [Icon(icon, size: 17, color: pink), const SizedBox(width: 6), Expanded(child: Text(label)), Text('$value%')]),
    const SizedBox(height: 4), LinearProgressIndicator(value: value / 100, minHeight: 8, borderRadius: BorderRadius.circular(8)),
  ]));
  @override
  Widget build(BuildContext context) => ListView(children: [
    heading('Our pets 🐾', 'Take care of your fire-and-water duo.'),
    softCard(child: Column(children: [
      const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        CharacterBadge(emoji: '🔥', name: 'Ember'),
        CharacterBadge(emoji: '💧', name: 'Wade'),
      ]),
      const SizedBox(height: 12),
      Text('Outfit: ${outfits[outfit]}', style: const TextStyle(fontWeight: FontWeight.w700)),
      const SizedBox(height: 6),
      Wrap(spacing: 8, children: [
        OutlinedButton(onPressed: () => setState(() => outfit = (outfit + 1) % outfits.length), child: const Text('Change outfit')),
      ]),
    ])),
    softCard(child: Column(children: [
      meter('Fullness', hunger, Icons.restaurant),
      meter('Clean', clean, Icons.bathtub_outlined),
      meter('Happiness', happy, Icons.favorite),
      meter('Energy', energy, Icons.bedtime_outlined),
    ])),
    softCard(child: Wrap(alignment: WrapAlignment.spaceEvenly, spacing: 8, runSpacing: 8, children: [
      FilledButton.tonal(onPressed: () => change('Feed'), child: const Text('🍓 Feed')),
      FilledButton.tonal(onPressed: () => change('Groom'), child: const Text('🫧 Groom')),
      FilledButton.tonal(onPressed: () => change('Play'), child: const Text('🧸 Play')),
      FilledButton.tonal(onPressed: () => change('Nap'), child: const Text('🌙 Nap')),
    ])),
  ]);
}

class LoveEvent {
  String title;
  DateTime date;
  LoveEvent(this.title, this.date);
}

class LovePage extends StatefulWidget {
  const LovePage({super.key});
  @override
  State<LovePage> createState() => _LovePageState();
}

class _LovePageState extends State<LovePage> {
  final List<LoveEvent> events = [];
  Future<void> addEvent() async {
    final title = TextEditingController();
    DateTime date = DateTime.now();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setDialog) => AlertDialog(
      title: const Text('Add a special date 💗'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: title, decoration: const InputDecoration(labelText: 'Event name', hintText: 'e.g. Monthsary')),
        const SizedBox(height: 12),
        OutlinedButton.icon(onPressed: () async {
          final d = await showDatePicker(context: ctx, initialDate: date, firstDate: DateTime(2000), lastDate: DateTime(2100));
          if (d != null) setDialog(() => date = d);
        }, icon: const Icon(Icons.calendar_month), label: Text('${date.day}/${date.month}/${date.year}')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save'))],
    )));
    if (ok == true && title.text.trim().isNotEmpty) setState(() => events.add(LoveEvent(title.text.trim(), date)));
  }
  int daysUntil(DateTime date) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    var next = DateTime(today.year, date.month, date.day);
    if (next.isBefore(today)) next = DateTime(today.year + 1, date.month, date.day);
    return next.difference(today).inDays;
  }
  @override
  Widget build(BuildContext context) => ListView(children: [
    heading('Our love calendar 💌', 'Add and customize your own special dates.'),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: FilledButton.icon(onPressed: addEvent, icon: const Icon(Icons.add), label: const Text('Add special date'))),
    if (events.isEmpty) softCard(child: const Text('No dates added yet. Add your monthsary, anniversary, birthdays, or any day that matters to you.')),
    ...events.map((e) => Dismissible(key: ObjectKey(e), direction: DismissDirection.endToStart, onDismissed: (_) => setState(() => events.remove(e)), background: Container(alignment: Alignment.centerRight, margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 7), padding: const EdgeInsets.only(right: 20), decoration: BoxDecoration(color: Colors.red.shade100, borderRadius: BorderRadius.circular(22)), child: const Icon(Icons.delete)), child: softCard(child: Row(children: [
      const CircleAvatar(backgroundColor: Color(0xFFFFEEF3), child: Icon(Icons.favorite, color: pink)),
      const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(e.title, style: const TextStyle(fontWeight: FontWeight.bold)), Text('${e.date.day}/${e.date.month}/${e.date.year}', style: const TextStyle(color: Colors.black54))])),
      Text('${daysUntil(e.date)} days', style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFFB64F78))),
    ])))),
    const Padding(padding: EdgeInsets.all(16), child: Text('Swipe a date left to remove it. This prototype currently stores dates only while the app is open.', style: TextStyle(fontSize: 12, color: Colors.black54))),
  ]);
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(children: [
    heading('Settings ⚙️', 'Make this little world yours.'),
    softCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
      Text('Couple connection', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      SizedBox(height: 8),
      Text('Partner invite codes and live synchronization will be added with a secure backend in the next development stage.'),
    ])),
    softCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
      Text('Widgets', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
      SizedBox(height: 8),
      Text('The Android widget extension needs to be connected and tested on both phones. This starter includes the Flutter integration dependency only.'),
    ])),
    softCard(child: const Text('Prototype note: your drawings, pet stats, and calendar events are not yet shared or backed up.')),
  ]);
}
