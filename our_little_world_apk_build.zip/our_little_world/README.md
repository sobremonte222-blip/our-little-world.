# Our Little World — Flutter starter

A cute pastel couples-app prototype with a drawing canvas, virtual-pet care controls, outfit selector, special-date countdowns, and five-tab navigation.

## Build an Android APK using GitHub (no Flutter installation needed on your phone)

1. Download and extract this ZIP on a computer, or upload the ZIP contents to a new GitHub repository.
2. Sign in to GitHub and create a **new repository**.
3. Upload the extracted project files and folders (make sure the `.github` folder is included) and commit them to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build Android APK** on the left.
6. Tap **Run workflow** and confirm. You can also let it build automatically after pushing to `main`.
7. Wait for the workflow to finish with a green check. Open that run, scroll to **Artifacts**, and download **our-little-world-apk**.
8. Extract the downloaded artifact ZIP. It contains `app-release.apk`. Transfer it to your Android phone and install it. Android may ask you to allow installation from that file app. Only install APKs you built or trust.

The workflow creates the Android Gradle project files on GitHub, builds the release APK, and uploads it as an artifact. The APK is **not included in this starter ZIP**; GitHub must complete the build first.

## Run locally (optional)

Install Flutter and Android Studio, then run:

```bash
flutter pub get
flutter run
```

## Prototype limitations

This is not yet a complete shared couples app. It does not currently include account creation, partner invitation, cloud synchronization between phones, durable saving of drawings/pet/date data, functional Android home-screen widgets, mini-games, or final character illustrations/animations. The `home_widget` and `shared_preferences` packages are included for future development, but those features are not fully implemented.

The fire-and-water duo currently uses emoji placeholders. For a public release, use original artwork or obtain permission to distribute official movie character art.
